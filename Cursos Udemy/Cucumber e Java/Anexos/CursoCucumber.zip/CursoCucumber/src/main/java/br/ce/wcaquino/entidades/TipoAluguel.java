package br.ce.wcaquino.entidades;

public enum TipoAluguel {

	COMUM, EXTENDIDO, SEMANAL;
}
