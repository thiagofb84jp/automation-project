package integracao.bancodedados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancodedadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancodedadosApplication.class, args);
	}
}
