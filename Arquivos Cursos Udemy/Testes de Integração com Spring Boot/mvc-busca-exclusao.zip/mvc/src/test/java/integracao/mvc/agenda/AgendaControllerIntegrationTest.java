package integracao.mvc.agenda;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import integracao.mvc.contatos.Contato;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestEntityManager
@Transactional
public class AgendaControllerIntegrationTest {

	@Autowired
	private TestEntityManager testEntityManager;

	@Autowired
	private MockMvc mockMvc;

	private Contato contato;

	@Before
	public void start() {
		contato = new Contato("Chefe", "0y", "9xxxxxxx9");
	}

	@After
	public void end() {
		testEntityManager.getEntityManager().createQuery("DELETE FROM Contato").executeUpdate();
	}

	@Test
	public void deveMostrarTodosOsContatos() throws Exception {
		testEntityManager.persist(contato);
		mockMvc.perform(get("/agenda/"))
		.andExpect(status().isOk())
		.andExpect(view().name("agenda"))
		.andExpect(model().attribute("contatos", Matchers.hasSize(1)))
		.andExpect(model().attribute("contatos", Matchers.hasItem(
				Matchers.allOf(
						Matchers.hasProperty("id", Matchers.is(contato.getId())),
						Matchers.hasProperty("nome", Matchers.is(contato.getNome())),
						Matchers.hasProperty("ddd", Matchers.is(contato.getDdd())),
						Matchers.hasProperty("telefone", Matchers.is(contato.getTelefone()))
						)
				)))
		.andDo(print());
	}

	@Test
	public void deveMostrarUmContato() throws Exception {
		Long id = (Long) testEntityManager.persistAndGetId(contato);
		mockMvc.perform(get("/agenda/contato/{id}",id))
		.andExpect(status().isOk())
		.andExpect(view().name("agenda/contato"))
		.andExpect(model().attribute("contato", Matchers.any(Contato.class)))
		.andExpect(model().attribute("contato",contato))
		.andDo(print());
	}

	@Test
	public void removerDeveExcluirContato() throws Exception {
		Long id = (Long) testEntityManager.persistAndGetId(contato);
		mockMvc.perform(get("/agenda/remover/{id}",id))
		.andExpect(status().is3xxRedirection())
		.andExpect(view().name("redirect:agenda/"))
		.andExpect(flash().attribute("successMessage", "Contato removido com sucesso"))
		.andDo(print());

		Query query = testEntityManager.getEntityManager().createQuery("SELECT c FROM Contato c");
		List<Contato> resultList = query.getResultList();

		Assert.assertEquals(0, resultList.size());
	}

}
