package integracao.mvc.agenda;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import integracao.mvc.contatos.Contato;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestEntityManager
@Transactional
public class AgendaControllerIntegrationTest {

	@Autowired
	private TestEntityManager testEntityManager;

	@Autowired
	private MockMvc mockMvc;

	private String nome = "Chefe";

	private String ddd = "0y";

	private String telefone = "9xxxxxxx9";

	@After
	public void end() {
		testEntityManager.getEntityManager().createQuery("DELETE FROM Contato").executeUpdate();
	}

	@Test
	public void inserirComDddNuloDeveRetornarUmErro() throws Exception {
		mockMvc.perform(post("/agenda/inserir")
				.param("telefone", telefone)
				.param("nome", nome)
				)
		.andExpect(status().isOk())
		.andExpect(view().name("agenda/inserir"))
		.andExpect(model().attribute("contato", Matchers.any(Contato.class)))
		.andExpect(model().attributeHasFieldErrors("contato", "ddd"))
		.andExpect(model().attributeHasFieldErrorCode("contato", "ddd", "NotEmpty"))
		.andDo(print());
	}

	@Test
	public void inserirComTelefoneNuloDeveRetornarUmErro() throws Exception {
		mockMvc.perform(post("/agenda/inserir")
				.param("ddd", ddd)
				.param("nome", nome)
				)
		.andExpect(status().isOk())
		.andExpect(view().name("agenda/inserir"))
		.andExpect(model().attribute("contato", Matchers.any(Contato.class)))
		.andExpect(model().attributeHasFieldErrors("contato", "telefone"))
		.andExpect(model().attributeHasFieldErrorCode("contato", "telefone", "NotEmpty"))
		.andDo(print());
	}

	@Test
	public void inserirComNomeNuloDeveRetornarUmErro() throws Exception {
		mockMvc.perform(post("/agenda/inserir")
				.param("ddd", ddd)
				.param("telefone", telefone)
				)
		.andExpect(status().isOk())
		.andExpect(view().name("agenda/inserir"))
		.andExpect(model().attribute("contato", Matchers.any(Contato.class)))
		.andExpect(model().attributeHasFieldErrors("contato", "nome"))
		.andExpect(model().attributeHasFieldErrorCode("contato", "nome", "NotEmpty"))
		.andDo(print());
	}

	@Test
	public void inserirDeveSalvaContato() throws Exception {
		mockMvc.perform(post("/agenda/inserir")
				.param("ddd", ddd)
				.param("telefone", telefone)
				.param("nome", nome)
				)
		.andExpect(status().isOk())
		.andExpect(view().name("agenda/inserir"))
		.andExpect(model().attribute("contato", Matchers.any(Contato.class)))
		.andExpect(model().attribute("successMessage", "Contato cadastrado com sucesso"))
		.andDo(print());

		Query query = testEntityManager.getEntityManager().createQuery("SELECT c FROM Contato c");
		List<Contato> resultList = query.getResultList();
		Assert.assertEquals(1, resultList.size());
	}

}
